﻿Additional Features
1.) All Clear Button (Clears the calculator)
2.) Delete Button (allows user to backspace if they push the wrong button.)